import torch
import pickle
import argparse
import numpy as np
import pandas as pd
import random


def get_parser():
    parser = argparse.ArgumentParser(description='multi-stream ensemble')
    # 添加命令行参数
    parser.add_argument(
        '--Score_1', type=str, default='beifen/后处理/文档/1_ctr_bone_4302/pred.npy'),
    parser.add_argument(
        '--Score_2', type=str, default='beifen/后处理/文档/2_ctr_bone_4356/pred.npy'),
    parser.add_argument(
        '--Score_3', type=str, default='beifen/后处理/文档/3_ctr_joint_4404/pred.npy'),
    parser.add_argument(
        '--Score_4', type=str, default='beifen/后处理/文档/4_ctr_joint_bone_4337/pred.npy'),
    parser.add_argument(
        '--Score_5', type=str, default='beifen/后处理/文档/5_ctr_joint_bone_4435/pred.npy'),
    parser.add_argument(
        '--Score_6', type=str, default='beifen/后处理/文档/6_td_bone_4277/pred.npy'),
    parser.add_argument(
        '--Score_7', type=str, default='beifen/后处理/文档/7_td_joint_4300/pred.npy'),
    parser.add_argument(
        '--Score_8', type=str, default='beifen/后处理/文档/8_td_joint_bone_4393/pred.npy'),
    parser.add_argument(
        '--Score_9', type=str, default='beifen/后处理/文档/9_te_bone_42.65/pred.npy'),
    parser.add_argument(
        '--Score_10', type=str, default='beifen/后处理/文档/10_te_joint_43.35/pred.npy'),
    parser.add_argument(
        '--Score_11', type=str, default='beifen/后处理/文档/11_te_joint_bone_43.63/pred.npy'),
    parser.add_argument('--val_sample', type=str, default='./Process_data/CS_test_V2.txt')
    parser.add_argument('--benchmark', type=str, default='V2')
    return parser

def Cal_Score(File, Rate, ntu60XS_num, Numclass):
    final_score = torch.zeros(ntu60XS_num, Numclass)
    for idx, file in enumerate(File):
        inf = np.load(file, allow_pickle=True)
        score = torch.tensor(inf, dtype=torch.float32)
        if score.shape != (ntu60XS_num, Numclass):
            raise ValueError("The shape of the score tensor does not match the expected shape.")
        final_score += Rate[idx] * score
    final_score_np = final_score.numpy()
    np.save('work_dir/final_score_np.npy', final_score_np)
    return final_score


def Cal_Acc(final_score, true_label):
    wrong_index = []
    _, predict_label = torch.max(final_score, 1)
    for index, p_label in enumerate(predict_label):
        if p_label != true_label[index]:
            wrong_index.append(index)
    wrong_num = np.array(wrong_index).shape[0]
    total_num = true_label.shape[0]
    Acc = (total_num - wrong_num) / total_num
    return Acc

def gen_label(val_txt_path):
    true_label = []
    val_txt = np.loadtxt(val_txt_path, dtype=str)
    for name in val_txt:
        label = int(name.split('A')[1][:3])
        true_label.append(label)
    true_label = torch.from_numpy(np.array(true_label))
    return true_label


class Particle:
    def __init__(self, rates, tolerance=2):
        
        self.position = [random.uniform(rate - tolerance, rate + tolerance) for rate in rates]
        self.velocity = [random.uniform(-1, 1) for _ in rates]
        self.best_position = self.position[:]
        self.best_score = float('-inf')
    
    def update_velocity(self, global_best_position, inertia=0.59618, cognitive=0.7298, social=1.298):
        for i in range(len(self.velocity)):
            r1, r2 = random.random(), random.random()
            cognitive_velocity = cognitive * r1 * (self.best_position[i] - self.position[i])
            social_velocity = social * r2 * (global_best_position[i] - self.position[i])
            self.velocity[i] = inertia * self.velocity[i] + cognitive_velocity + social_velocity
    
    def update_position(self, rates, tolerance=1.8):
        for i in range(len(self.position)):
            self.position[i] += self.velocity[i]
            self.position[i] = max(min(self.position[i], rates[i] + tolerance), rates[i] - tolerance)


def pso(rates, File, ntu60XS_num, Numclass, true_label, num_particles=100, max_iterations=100):
    particles = [Particle(rates) for _ in range(num_particles)]
    global_best_position = rates[:]
    global_best_score = float('-inf')

    for iteration in range(max_iterations):
        for particle in particles:
            final_score = Cal_Score(File, particle.position, ntu60XS_num, Numclass)
            Acc = Cal_Acc(final_score, true_label)
            if Acc > particle.best_score:
                particle.best_score = Acc
                particle.best_position = particle.position[:]
            
            if Acc > global_best_score:
                global_best_score = Acc
                global_best_position = particle.position[:]

        for particle in particles:
            particle.update_velocity(global_best_position)
            particle.update_position(rates)

        print(f"Iteration {iteration + 1}/{max_iterations}, Best Accuracy: {global_best_score}")

    return global_best_position, global_best_score

if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()

    file_1 = args.Score_1
    file_2 = args.Score_2
    file_3 = args.Score_3
    file_4 = args.Score_4
    file_5 = args.Score_5
    file_6 = args.Score_6
    file_7 = args.Score_7
    file_8 = args.Score_8
    file_9 = args.Score_9
    file_10 = args.Score_10
    file_11 = args.Score_11

    File = [file_9, file_10, file_11, file_1, file_2, file_3, file_4, file_5, file_6, file_7, file_8]


    if args.benchmark == 'V2':
        Numclass = 155
        Sample_Num = 2000
        true_label = np.load(r'data\val_label.npy')

        best_position, best_score = pso([0.0, 0.0, 0.0, 4.0, 4.0, 4.0, 8.0, 2.0, 4.0, 0.0, 4.0], File, Sample_Num, Numclass, true_label)
        print('Best Accuracy: ', best_score)
        print('Best Rate: ', best_position)