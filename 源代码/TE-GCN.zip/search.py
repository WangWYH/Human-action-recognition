import argparse
import numpy as np
import torch
from itertools import product


def get_parser():
    parser = argparse.ArgumentParser(description='multi-stream ensemble')
    parser.add_argument(
        '--Score_1', type=str, default='beifen/后处理/文档/1_ctr_bone_4302/pred.npy'),
    parser.add_argument(
        '--Score_2', type=str, default='beifen/后处理/文档/2_ctr_bone_4356/pred.npy'),
    parser.add_argument(
        '--Score_3', type=str, default='beifen/后处理/文档/3_ctr_joint_4404/pred.npy'),
    parser.add_argument(
        '--Score_4', type=str, default='beifen/后处理/文档/4_ctr_joint_bone_4337/pred.npy'),
    parser.add_argument(
        '--Score_5', type=str, default='beifen/后处理/文档/5_ctr_joint_bone_4435/pred.npy'),
    parser.add_argument(
        '--Score_6', type=str, default='beifen/后处理/文档/6_td_bone_4277/pred.npy'),
    parser.add_argument(
        '--Score_7', type=str, default='beifen/后处理/文档/7_td_joint_4300/pred.npy'),
    parser.add_argument(
        '--Score_8', type=str, default='beifen/后处理/文档/8_td_joint_bone_4393/pred.npy'),
    parser.add_argument(
        '--Score_9', type=str, default='beifen/后处理/文档/9_te_bone_42.65/pred.npy'),
    parser.add_argument(
        '--Score_10', type=str, default='beifen/后处理/文档/10_te_joint_43.35/pred.npy'),
    parser.add_argument(
        '--Score_11', type=str, default='beifen/后处理/文档/11_te_joint_bone_43.63/pred.npy'),
    parser.add_argument(
        '--val_sample',
        type=str,
        default='./Process_data/CS_test_V2.txt'),
    parser.add_argument(
        '--benchmark',
        type=str,
        default='V2')
    return parser


def Cal_Score(File, Rate, ntu60XS_num, Numclass):
    final_score = torch.zeros(ntu60XS_num, Numclass)
    for idx, file in enumerate(File):
        inf = np.load(file, allow_pickle=True)
        score = torch.tensor(inf, dtype=torch.float32)
        if score.shape != (ntu60XS_num, Numclass):
            raise ValueError("The shape of the score tensor does not match the expected shape.")
        final_score += Rate[idx] * score
    final_score_np = final_score.numpy()
    np.save('work_dir/search_pred.npy', final_score_np)
    return final_score


def Cal_Acc(final_score, true_label):
    wrong_index = []
    _, predict_label = torch.max(final_score, 1)
    for index, p_label in enumerate(predict_label):
        if p_label != true_label[index]:
            wrong_index.append(index)
    wrong_num = np.array(wrong_index).shape[0]
    total_num = true_label.shape[0]
    Acc = (total_num - wrong_num) / total_num
    return Acc


if __name__ == "__main__":
    parser = get_parser()
    args = parser.parse_args()

    file_1 = args.Score_1
    file_2 = args.Score_2
    file_3 = args.Score_3
    file_4 = args.Score_4
    file_5 = args.Score_5
    file_6 = args.Score_6
    file_7 = args.Score_7
    file_8 = args.Score_8
    file_9 = args.Score_9
    file_10 = args.Score_10
    file_11 = args.Score_11

    File = [file_9, file_10, file_11, file_1, file_2, file_3, file_4, file_5, file_6, file_7, file_8]
    true_label = np.load('data/val_label.npy')
    Numclass = 155
    Sample_Num = 2000

    # 设置搜索起点
    start_rate = [0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]

    rate_range_front = np.arange(0, 1.1, 0.2)  # For the first three rates, range is 0 to 1
    rate_range_back = np.arange(0, 10.1, 2)  # For the last three rates, range is 0 to 5


    best_acc = 0
    best_rate = None

    # 生成所有可能的Rate组合
    for rate_front, rate_back in product(product(rate_range_front, repeat=3), product(rate_range_back, repeat=8)):
        current_rate = rate_front + rate_back

        # 第一次迭代时，确保Rate组合大于等于起点
        if best_rate is None:
            if all(r >= start_rate[i] for i, r in enumerate(current_rate)):
                final_score = Cal_Score(File, current_rate, Sample_Num, Numclass)
                acc = Cal_Acc(final_score, true_label)
                if acc > best_acc:
                    best_acc = acc
                    best_rate = current_rate
                    print(f'Initial Rate: {best_rate}, Initial Acc: {best_acc:.4f}')
        else:
            final_score = Cal_Score(File, current_rate, Sample_Num, Numclass)
            acc = Cal_Acc(final_score, true_label)
            if acc > best_acc:
                best_acc = acc
                best_rate = current_rate
                print(f'Current Rate: {best_rate}, Current Acc: {best_acc:.4f}')

    print('Best Acc:', best_acc)
    print('Best Rate:', best_rate)
