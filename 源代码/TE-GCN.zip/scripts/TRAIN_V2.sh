#!/bin/bash
RECORD=2102
WORKDIR=work_dir/$RECORD
MODELNAME=runs/$RECORD

CONFIG=./config/uav-cross-subjectv2/train.yaml

START_EPOCH=50
EPOCH_NUM=60
BATCH_SIZE=48
WARM_UP=5
SEED=777

python main.py --config ./config/uav-cross-subjectv2/train.yaml --work-dir ./work_dir/2102 -model_saved_name ./runs/2102 --device 0 --warm_up_epoch 5 --only_train_epoch 60 --seed 777

