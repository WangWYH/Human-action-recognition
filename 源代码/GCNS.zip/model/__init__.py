from . import agcn, aagcn, tegcn, module_ta, ctrgcn, mstgcn, mix_gcn, st_gcn
#from . import shift_gcn
from .tcn import Model as TCN
from .st_gcn import Model as ST_GCN
from . import ske_mixf
from . import spa_mixf
from . import tem_mixf
from . import sttformer
from . import tdgcn