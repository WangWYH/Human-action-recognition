Run `bash run.sh` to compile the cuda extension of temporal adaptive shift op.
This implementation borrows from active-shift in Caffe by jyh2986. We modified it for temporal adaptive shift.